﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loop_pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             1
             2 3
             6 18 108
             */

            //do while loop
            Console.Write("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, old = 2, New = 3, k = 1;
            do
            {
                int j = 1;
                do
                {
                    if (k <= 3)
                    {
                        Console.Write(k + " ");
                    }
                    else
                    {
                        k = old * New;
                        if (k > n)
                        {
                            break;
                        }
                        Console.Write(k + " ");
                        old = New;
                        New = k;
                    }
                    k++;
                    j++;
                }
                while (j <= i);
                i++;
                if (k > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            while (i <= n);
            Console.Read();

            //for loop
            /*
            int i, j, k = 1, b;
            for (i = 1; i <= n; i++)
            {
                for (j = 1; j <= i; j++)
                {
                    Console.Write(k);
                    k = b;
                    b = k * b;
                }
                Console.WriteLine();
            }
            Console.Read();
            */
            //while loop
            /*
            int i, j, k = 1, b;
            while (i <= n)
            {
                while (j <= i)
                {
                    Console.Write(k);
                    k = b;
                    b = k * b;
                }
                Console.WriteLine();
            }
            Console.Read();
            */
        }
    }
}
