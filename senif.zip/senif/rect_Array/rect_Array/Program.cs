﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rect_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[, ,] a = new int[3, 3, 3];
            a[0, 0, 0] = 10;
            a[0, 0, 1] = 20;
            a[0, 0, 2] = 30;
            a[0, 1, 0] = 40;
            a[0, 1, 1] = 50;
            a[0, 1, 2] = 60;

            foreach (int i in a)
            {
                Console.Write(i + " ");
            }
            Console.Read();
        }
    }
}
