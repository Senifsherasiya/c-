﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conditionalstatement
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.Write("enter your age:");
            age = Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age < 18)
                {
                    Console.WriteLine("teenage");
                }
                else if (age >= 18 && age < 60)
                {
                    Console.WriteLine("yong");
                }
                else
                {
                    Console.WriteLine("senior citzen");
                }
            }
            else
            {
                Console.WriteLine("birth pending");
            }
            Console.Read();
        }
    }
}
