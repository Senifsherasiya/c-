﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set console color RED=1");
            Console.WriteLine("set console color GREEN=2");
            Console.WriteLine("set console color BLUE=3");
            int n = Convert.ToInt32(Console.ReadLine());

            switch (n)
            {
                case 1: Console.BackgroundColor = Console.Color.Red;
                Console.Clear();
                break;

                case 2: Console.BackgroundColor = Console.Color.Green;
                Console.Clear();
                break;

                case 3: Console.BackgroundColor = Console.Color.Blue;
                Console.Clear();
                break;

                default : Console.Write("please select 1 2 3");
                break;
            }
            Console.Read();
        }
    }
}
